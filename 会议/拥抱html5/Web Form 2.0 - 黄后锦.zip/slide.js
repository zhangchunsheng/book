(function(win, doc){
if (!Function.prototype.bind) {
    Function.prototype.bind = function (bind) {
		var self = this,
			args = (arguments.length > 1) ? [].slice.call(arguments, 1) : null;
		
		return function(){
			if (!args && !arguments.length) return self.call(bind);
			if (args && arguments.length) return self.apply(bind, args.concat([].slice.call(arguments)));
			return self.apply(bind, args || arguments);
		};
    };
}
var Slide = {

    id : '#sliders',
    index: 0,
    fadeClass: '.fade',
    fadeInClass: 'in',
    hash: 'slide',
    height: 600,
    keyDelay: 600,
    pages: 'footer time span',
    progresses: '#stat progress',
    tag: 'section',
    time: 30,

    init: function (opt) {
        var self = this,
            el = self.element = doc.querySelector(self.id),
            hash = (location.hash.replace('#' + self.hash, '') | 0) - 1,
            ua = navigator.userAgent.toLowerCase(),
            bound = self.bound = {
                jump: self.onJump.bind(self),
                keyup: self.onKeyup.bind(self),
                scroll: self.onScroll.bind(self),
                time: self.timeLeft.bind(self)
            };
        
        opt = opt.split('&');
        if (opt.length) {
            opt.forEach(function (item) {
                item = item.split('=');
                if (typeof self[item[0]] != 'function') {
                    self[item[0]] = item[1];
                }
            });
        }
        
        self.sections = [].slice.call(el.querySelectorAll(self.tag));
        self.max = self.sections.length - 1;
        self.progresses = doc.querySelectorAll(self.progresses);
        self.pages = doc.querySelectorAll(self.pages);
        self.pages[1].textContent = self.max + 1;
        
        doc.addEventListener('keyup', bound.keyup, false);
        doc.addEventListener(ua.indexOf('firefox') > 0 ? 'DOMMouseScroll' : 'mousewheel', bound.scroll, false);
        self.keys = [];
        self.fadeMaps = {};
        self.begin = +new Date;
        self.spanTimer = setInterval(bound.time, 1000);
        if(hash > 0) self.move(hash);
    },

    onScroll: function (e) {
        var self = this;
        self.move(self.index + (e.wheelDelta ? -e.wheelDelta / 120 : (e.detail || 0) / 3), e);
    },

    onKeyup: function (e) {
        var self = this,
            index = self.index,
            code = e.which || e.keyCode;
        switch(code){
        case 35:
            index = self.max;
        break;
        case 36:
            index = 0;
        break;
        case 37:
            return self.fade(-1);
        break;
        case 39:
            return self.fade(1);
        break;
        case 38:
            index --;
        break;
        case 40:
            index ++;
        break;
        default:
            if (e.shiftKey && e.ctrlKey) {
                if (code > 47 && code < 58) {
                    clearTimeout(self.timer);
                    self.keys.push(code - 48);
                    self.timer = setTimeout(self.bound.jump, self.keyDelay);
                }
            }
        break;
        }
        self.move(index, e);
    },

    onJump: function () {
        var self = this;
        clearTimeout(self.timer);
        self.move((self.keys.join('') | 0) - 1);
        self.keys = [];
    },

    move: function (i, e, undefined) {
        e && e.preventDefault();
        var self = this,
            index = self.index;
        if(i === index) return;
        i = self.index = Math.min(Math.max(0, i), self.max);
        self.element.style.marginTop = - self.height * i + 'px';
        if(self.fadeMaps[i] === undefined) self.fadeMaps[i] = -1;
        i ++;
        location.hash = self.hash + i;
        if(self.progresses[1]) self.progresses[1].value = i * 100 / (self.max + 1) | 0;
        self.pages[0].textContent = i;
    },

    fade: function (step) {
        var self = this,
            section = self.sections[self.index],
            index = self.fadeMaps[self.index],
            cls = self.fadeInClass,
            els,
            el;
        if (!section) return;
        els = section.querySelectorAll(self.fadeClass);
        el = step > 0 ? els[index + step] : els[index];
        if (!el) {
            return self.move(self.index + step);
        }
        if ( step < 0 ) {
            el.className = el.className.replace(new RegExp('(^|\\s)' + cls + '(?:\\s|$)'), '$1');
        } else {
            el.className = (el.className + ' ' + cls).replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
        }
        self.fadeMaps[self.index] = index + step;
    },

    timeLeft: function () {
        var self = this,
            progress = self.progresses[0],
            value = (+new Date - self.begin)/60000 | 0;
        if(progress) progress.value = value;
        if(value >= 100) clearInterval(self.spanTimer);
    }
},
domready = 'DOMContentLoaded',
scripts = doc.getElementsByTagName('script'),
script = scripts[scripts.length - 1],
params = script.getAttribute('data-params');

win.addEventListener(
    domready,
    function () {
        win.removeEventListener(domready, arguments.callee, false);
        Slide.init(params);
        if( win.opera ) doc.documentElement.className = 'opera';
    },
    false
);
win.addEventListener('resize', resize, false);
function resize(){
    var html = doc.documentElement,
        wrapperStyle;
    if(html.clientWidth > 800 && html.clientHeight > 600) {
        wrapperStyle = doc.querySelector('.wrapper').style;
        wrapperStyle.boxShadow ='rgba(140, 156, 173, .8) -8px -8px 15px';
        wrapperStyle.borderWidth = '1px';
    }

}
resize();
})(this, document);

(function (doc) {
    var canvas = doc.querySelector("#logo"),
        ctx = doc.querySelector('#triangle').getContext('2d');
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, 14);
    ctx.lineTo(12.1, 7);
    ctx.lineTo(0, 0);
    ctx.fillStyle = '#c8ff00';
    ctx.fill();
    ctx.closePath();
    ctx.strokeStyle = '#fff';
    ctx.stroke();


    ctx = canvas.getContext("2d");

    // The text (H)
    ctx.fillStyle = "#000000";
    ctx.beginPath();
    ctx.moveTo(16.9, 0.0);
    ctx.lineTo(20.5, 0.0);
    ctx.lineTo(20.5, 3.6);
    ctx.lineTo(23.8, 3.6);
    ctx.lineTo(23.8, 0.0);
    ctx.lineTo(27.4, 0.0);
    ctx.lineTo(27.4, 10.8);
    ctx.lineTo(23.8, 10.8);
    ctx.lineTo(23.8, 7.2);
    ctx.lineTo(20.5, 7.2);
    ctx.lineTo(20.5, 10.8);
    ctx.lineTo(16.9, 10.8);
    ctx.lineTo(16.9, 0.0);
    ctx.closePath();
    ctx.fill();

    // The text (T)
    ctx.beginPath();
    ctx.moveTo(32.2, 3.6);
    ctx.lineTo(29.0, 3.6);
    ctx.lineTo(29.0, 0.0);
    ctx.lineTo(39.0, 0.0);
    ctx.lineTo(39.0, 3.6);
    ctx.lineTo(35.8, 3.6);
    ctx.lineTo(35.8, 10.8);
    ctx.lineTo(32.2, 10.8);
    ctx.lineTo(32.2, 3.6);
    ctx.closePath();
    ctx.fill();

    // The text (M)
    ctx.beginPath();
    ctx.moveTo(40.5, 0.0);
    ctx.lineTo(44.3, 0.0);
    ctx.lineTo(46.6, 3.8);
    ctx.lineTo(48.9, 0.0);
    ctx.lineTo(52.7, 0.0);
    ctx.lineTo(52.7, 10.8);
    ctx.lineTo(49.1, 10.8);
    ctx.lineTo(49.1, 5.4);
    ctx.lineTo(46.6, 9.3);
    ctx.lineTo(44.1, 5.4);
    ctx.lineTo(44.1, 10.8);
    ctx.lineTo(40.5, 10.8);
    ctx.lineTo(40.5, 0.0);
    ctx.closePath();
    ctx.fill();

    // The text (L)
    ctx.beginPath();
    ctx.moveTo(54.5, 0.0);
    ctx.lineTo(58.1, 0.0);
    ctx.lineTo(58.1, 7.2);
    ctx.lineTo(63.1, 7.2);
    ctx.lineTo(63.1, 10.8);
    ctx.lineTo(54.5, 10.8);
    ctx.lineTo(54.5, 0.0);
    ctx.closePath();
    ctx.fill();

    // Dark background
    ctx.fillStyle = "#E44D26";
    ctx.beginPath();
    ctx.moveTo(16.8, 73.6);
    ctx.lineTo(11.7, 15.7);
    ctx.lineTo(68.3, 15.7);
    ctx.lineTo(63.2, 73.6);
    ctx.lineTo(40.0, 80.0);
    ctx.closePath();
    ctx.fill();

    // Light background
    ctx.fillStyle = "#F16529";
    ctx.beginPath();
    ctx.moveTo(40.0, 75.0);
    ctx.lineTo(58.7, 69.9);
    ctx.lineTo(63.2, 20.4);
    ctx.lineTo(40.0, 20.4);
    ctx.closePath();
    ctx.fill();

    // Dark foreground
    ctx.fillStyle = "#EBEBEB";
    ctx.beginPath();
    ctx.moveTo(40.0, 41.9);
    ctx.lineTo(30.6, 41.9);
    ctx.lineTo(30.0, 34.6);
    ctx.lineTo(40.0, 34.6);
    ctx.lineTo(40.0, 27.5);
    ctx.lineTo(40.0, 27.5);
    ctx.lineTo(22.2, 27.5);
    ctx.lineTo(22.4, 29.5);
    ctx.lineTo(24.1, 49.0);
    ctx.lineTo(40.0, 49.0);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(40.0, 60.3);
    ctx.lineTo(40.0, 60.3);
    ctx.lineTo(32.1, 58.2);
    ctx.lineTo(31.6, 52.6);
    ctx.lineTo(27.7, 52.6);
    ctx.lineTo(24.4, 52.6);
    ctx.lineTo(25.4, 63.7);
    ctx.lineTo(40.0, 67.7);
    ctx.lineTo(40.0, 67.7);
    ctx.closePath();
    ctx.fill();

    // Light foreground
    ctx.fillStyle = "#FFFFFF";
    ctx.beginPath();
    ctx.moveTo(40.0, 41.9);
    ctx.lineTo(40.0, 49.0);
    ctx.lineTo(48.7, 49.0);
    ctx.lineTo(47.9, 58.2);
    ctx.lineTo(40.0, 60.3);
    ctx.lineTo(40.0, 67.7);
    ctx.lineTo(54.5, 63.7);
    ctx.lineTo(54.6, 62.5);
    ctx.lineTo(56.3, 43.8);
    ctx.lineTo(56.5, 41.9);
    ctx.lineTo(54.6, 41.9);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(40.0, 27.5);
    ctx.lineTo(40.0, 31.9);
    ctx.lineTo(40.0, 34.6);
    ctx.lineTo(40.0, 34.6);
    ctx.lineTo(57.1, 34.6);
    ctx.lineTo(57.1, 34.6);
    ctx.lineTo(57.1, 34.6);
    ctx.lineTo(57.3, 33.0);
    ctx.lineTo(57.6, 29.5);
    ctx.lineTo(57.8, 27.5);
    ctx.closePath();
    ctx.fill();

    var imgSrc = canvas.toDataURL();
    [].forEach.call(doc.querySelectorAll('img.logo'), function (logo) {
        logo.src = imgSrc;
    });
})(document);