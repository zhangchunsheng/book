//
//  View.h
//  AFN-1.x
//
//  Created by Adm on 14-1-26.
//  Copyright (c) 2014年 Adm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface View : UIViewController
{
    AFHTTPClient *client;   //创建请求
}

@end
