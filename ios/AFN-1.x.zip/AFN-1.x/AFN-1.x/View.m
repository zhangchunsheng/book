//
//  View.m
//  AFN-1.x
//
//  Created by Adm on 14-1-26.
//  Copyright (c) 2014年 Adm. All rights reserved.
//

#import "View.h"

@interface View ()

@end

@implementation View

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    //GET请求的按钮
    UIButton *buttonGet = [UIButton buttonWithType:UIButtonTypeSystem];
    buttonGet.frame = CGRectMake(100, 100, 60, 20);
    [buttonGet setTitle:@"GET" forState:UIControlStateNormal];
    [buttonGet addTarget:self action:@selector(methodGet) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:buttonGet];
    
    //POST请求的按钮
    UIButton *buttonPost = [UIButton buttonWithType:UIButtonTypeSystem];
    buttonPost.frame = CGRectMake(160, 100, 60, 20);
    [buttonPost setTitle:@"POST" forState:UIControlStateNormal];
    [buttonPost addTarget:self action:@selector(methodPost) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:buttonPost];
    
    //Upload请求的按钮
    UIButton *buttonUpload = [UIButton buttonWithType:UIButtonTypeSystem];
    buttonUpload.frame = CGRectMake(100, 140, 60, 20);
    [buttonUpload setTitle:@"Upload" forState:UIControlStateNormal];
    [buttonUpload addTarget:self action:@selector(methodUpload) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:buttonUpload];
    
    //创建请求，设置接口路径
    client = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"接口共用的路径"]]];
}

#pragma mark - GET

//GET请求
- (void)methodGet
{
    //设置请求的解析器为AFJSONRequestOperation（用于解析JSON），默认为AFHTTPRequestOperation（用于直接解析数据NSData）
    [client registerHTTPOperationClass:[AFJSONRequestOperation class]];
    
    //添加JSON的数据类型，本Demo已在AFNetworking的源代码添加此数据类型，在AFJSONRequestOperation.m文件的第105行-第107行添加
//    [AFJSONRequestOperation addAcceptableContentTypes:[NSSet setWithObject:@"text/html"]];
    
    //设置转换的JSON格式，必须设置setDefaultHeader的值Accept以对应AFHTTPRequestOperation.m中的第322行的返回值中的Accept，系统才能获取请求，并返回JSON格式的文件
    [client setDefaultHeader:@"Accept" value:@"text/html"];
    
    //设置接口，并发送GET请求
    [client getPath:@"请求的接口" parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        //请求成功（当解析器为AFJSONRequestOperation时）
        NSLog(@"success:%@", responseObject);
        
        //请求成功（当解析器为AFHTTPRequestOperation时）
//        NSString *JSONString = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
//        NSLog(@"success:%@", JSONString);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        //请求失败
        NSLog(@"failure:%@", error);
        
    }];
}

#pragma mark - POST

//POST请求
- (void)methodPost
{
    //添加参数，Objective-C 2.0新语法
    NSDictionary *parameters = @{@"Key": @"Object",
                                 @"Key": @"Object"};
    //添加参数，旧语法
//    NSMutableDictionary *parameters = [[NSMutableDictionary alloc] init];
//    [parameters setObject:@"" forKey:@""];
    
    //设置请求的解析器为AFJSONRequestOperation（用于解析JSON），默认为AFHTTPRequestOperation（用于直接解析数据NSData）
    [client registerHTTPOperationClass:[AFJSONRequestOperation class]];
    
    //设置转换的JSON格式，必须设置setDefaultHeader的值Accept以对应AFHTTPRequestOperation.m中的第322行的返回值中的Accept，系统才能获取请求，并返回JSON格式的文件
    [client setDefaultHeader:@"Accept" value:@"text/html"];
    
    //设置接口，并发送POST请求
    [client postPath:@"请求的接口" parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        //请求成功（当解析器为AFJSONRequestOperation时）
        NSLog(@"success:%@", responseObject);
        
        //请求成功（当解析器为AFHTTPRequestOperation时）
//        NSString *JSONString = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
//        NSLog(@"success:%@", JSONString);
        
    }failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        //请求失败
        NSLog(@"failure:%@", error);
        
    }];
}

#pragma mark - Upload

//上传（以图片为例）
- (void)methodUpload
{
    //添加参数，Objective-C 2.0新语法
    NSDictionary *parameters = @{@"Key": @"Object",
                                 @"Key": @"Object"};
    //添加参数，旧语法
//    NSMutableDictionary *parameters = [[NSMutableDictionary alloc] init];
//    [parameters setObject:@"" forKey:@""];
    
    //设置请求的解析器为AFJSONRequestOperation（用于解析JSON），默认为AFHTTPRequestOperation（用于直接解析数据NSData）
    [client registerHTTPOperationClass:[AFJSONRequestOperation class]];
    
    //设置转换的JSON格式，必须设置setDefaultHeader的值Accept以对应AFHTTPRequestOperation.m中的第322行的返回值中的Accept，系统才能获取请求，并返回JSON格式的文件
    [client setDefaultHeader:@"Accept" value:@"text/html"];
    
    //设置接口，发送POST请求，添加需要发送的文件，此处为图片
    NSMutableURLRequest *request = [client multipartFormRequestWithMethod:@"POST" path:@"请求的接口" parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
        //添加图片，并对其进行压缩（0.0为最大压缩率，1.0为最小压缩率）
        NSData *imageData = UIImageJPEGRepresentation([UIImage imageNamed:@"图片名字"], 1.0);
        
        //添加要上传的文件，此处为图片
        [formData appendPartWithFileData:imageData name:@"服务器放图片的参数名（Key）" fileName:@"图片名字" mimeType:@"文件类型（此处为图片格式，如image/jpeg）"];
    }];
    
    //创建请求管理
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    
    //请求管理判断请求结果
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        //请求成功（当解析器为AFJSONRequestOperation时）
        NSLog(@"success:%@", responseObject);
        
        //请求成功（当解析器为AFHTTPRequestOperation时）
//        NSString *JSONString = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
//        NSLog(@"success:%@", JSONString);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        //请求失败
        NSLog(@"failure:%@", error);
        
    }];
    
    //请求开始
    [operation start];
}

#pragma mark - Memory Management

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
