//
//  main.m
//  AFN-1.x
//
//  Created by Adm on 14-1-26.
//  Copyright (c) 2014年 Adm. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
