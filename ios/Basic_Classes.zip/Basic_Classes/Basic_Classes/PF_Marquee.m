//
//  PF_Marquee.m
//  Basic_Classes
//
//  Created by Adm on 14-2-12.
//  Copyright (c) 2014年 PFei_He. All rights reserved.
//

#import "PF_Marquee.h"

@implementation PF_Marquee

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _motionWidth = 200;
    }
    return self;
}

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    if (self.tag == 1225) {
        float w  = self.frame.size.width;
        if (_motionWidth >= w)
        {
            return;
        }
        CGRect frame = self.frame;
        frame.origin.x = frame.origin.x - self.frame.size.width;
        self.frame = frame;
        [UIView beginAnimations:NULL context:NULL];
        [UIView setAnimationDuration:16.0f * (w < 320 ? 320 : w) / 320.0];
        [UIView setAnimationCurve:UIViewAnimationCurveLinear];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationRepeatAutoreverses:NO];
        [UIView setAnimationRepeatCount:LONG_MAX];
        
        frame = self.frame;
        frame.origin.x = -w;
        self.frame = frame;
        
        [UIView commitAnimations];
        
        return;
    }
    float w  = self.frame.size.width;
    if (_motionWidth >= w)
    {
        return;
    }
    CGRect frame = self.frame;
    frame.origin.x = 320;
    self.frame = frame;
    
    [UIView beginAnimations:NULL context:NULL];
    [UIView setAnimationDuration:16.0f * (w < 320 ? 320 : w) / 320.0];
    [UIView setAnimationCurve:UIViewAnimationCurveLinear];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationRepeatAutoreverses:NO];
    [UIView setAnimationRepeatCount:LONG_MAX];
    
    frame = self.frame;
    frame.origin.x = -w;
    self.frame = frame;
    [UIView commitAnimations];
}

@end
