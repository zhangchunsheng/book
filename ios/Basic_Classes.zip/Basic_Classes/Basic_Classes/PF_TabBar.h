//
//  PF_TabBar.h
//  Basic_Classes
//
//  Created by Adm on 14-2-12.
//  Copyright (c) 2014年 PFei_He. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PF_TabBar : UITabBarController
{
    UIView *_tabBarView;            //自定义一个TabBar
    NSArray *_heightBackground;     //选中按钮的图片
    NSArray *_background;           //未选中按钮的图片
    
    BOOL isSelect;                  //判断是否被选中
}

@property (nonatomic, strong) UIImageView *customTabBar;        //自定义TabBar的视图界面
@property (nonatomic, strong) NSMutableArray *selectArray;      //选中的按钮
@property (nonatomic, strong) NSMutableArray *unselectArray;    //未选中的按钮
@property (nonatomic, strong) NSMutableArray *tabBarButton;     //自定义tabBar上的按钮

/**
 *  @brief  获取TabBar选中的Button
 */
- (void)selectTabBar:(UIButton *)button;

/**
 *  @brief  隐藏TabBar
 */
- (void)setTabBarHidden:(BOOL)hidden andCustomTabBarHidden:(BOOL)hidden;

@end
