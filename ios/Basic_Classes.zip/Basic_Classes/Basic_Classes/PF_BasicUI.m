//
//  PF_BasicUI.m
//  Basic_Classes
//
//  Created by Adm on 14-2-12.
//  Copyright (c) 2014年 PFei_He. All rights reserved.
//

#import "PF_BasicUI.h"

@implementation PF_BasicUI

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

+ (UIButton *)buttonWithType:(UIButtonType)buttonType
                    andFrame:(CGRect)buttonFrame
                    andTitle:(NSString *)buttonTitle
                andTitleFont:(int)titleFont
               andTitleColor:(UIColor *)titleColor
                    andImage:(UIImage *)buttonImage
            andSelectedImage:(UIImage *)buttonSelectedImage
          andBackgroundImage:(UIImage *)buttonBackgroundImage
  andSelectedBackgroundImage:(UIImage *)buttonSelectedBackgroundImage
                   andTarget:(id)buttonTarget
                   andAction:(SEL)buttonAction
            andControlEvents:(UIControlEvents)buttonForControlEvents
{
     UIButton *button = [UIButton buttonWithType:buttonType];
     button.frame = buttonFrame;
     [button setTitle:buttonTitle forState:UIControlStateNormal];
     button.titleLabel.font = [UIFont systemFontOfSize:titleFont];
     [button setTitleColor:titleColor forState:UIControlStateNormal];
     [button setImage:buttonImage forState:UIControlStateNormal];
     [button setImage:buttonSelectedImage forState:UIControlStateSelected];
     [button setBackgroundImage:buttonBackgroundImage forState:UIControlStateNormal];
     [button setBackgroundImage:buttonSelectedBackgroundImage forState:UIControlStateSelected];
     [button addTarget:buttonTarget action:buttonAction forControlEvents:buttonForControlEvents];
     
     return button;
}

+ (UILabel *)labelWithFrame:(CGRect)labelFrame
                    andText:(NSString *)labelText
                    andFont:(NSInteger)labelFont
           andTextAlignment:(NSTextAlignment)labelTextAlignment
               andTextColor:(UIColor *)labelTextColor
         andBackgroundColor:(UIColor *)labelBackgroundColor
{
    UILabel *label = [[UILabel alloc] initWithFrame:labelFrame];
    label.text = labelText;
    label.font = [UIFont systemFontOfSize:labelFont];
    label.textAlignment = labelTextAlignment;
    label.textColor = labelTextColor;
    label.backgroundColor = labelBackgroundColor;
    
    return label;
}

+ (UITextField *)textWithFrame:(CGRect)textFrame
                andBorderStyle:(UITextBorderStyle)textBorderStyle
                       andText:(NSString *)textText
                andPlaceholder:(NSString *)textPlaceholder
                       andFont:(NSInteger)textFont
              andTextAlignment:(NSTextAlignment)textTextAlignment
                  andTextColor:(UIColor *)textTextColor
            andBackgroundColor:(UIColor *)textBackgroundColor
       andClearsOnBeginEditing:(BOOL)textClearsOnBeginEditing
{
    UITextField *text = [[UITextField alloc] initWithFrame:textFrame];
    text.borderStyle = textBorderStyle;
    text.text = textText;
    text.placeholder = textPlaceholder;
    text.font = [UIFont systemFontOfSize:textFont];
    text.textAlignment = textTextAlignment;
    text.textColor = textTextColor;
    text.backgroundColor = textBackgroundColor;
    text.clearsOnBeginEditing = textClearsOnBeginEditing;
    
    return text;
}

+ (UITextView *)textWithFrame:(CGRect)textFrame
                      andText:(NSString *)textText
                      andFont:(NSInteger)textFont
                 andTextColor:(UIColor *)textTextColor
           andBackgroundColor:(UIColor *)textBackgroundColor
                  andEditable:(BOOL)textEditable
             andScrollEnabled:(BOOL)textScrollEnabled
          andAutoresizingMask:(UIViewAutoresizing)textAutoresizingMask
{
    UITextView *text = [[UITextView alloc] initWithFrame:textFrame];
    text.text = textText;
    text.font = [UIFont systemFontOfSize:textFont];
    text.textColor = textTextColor;
    text.backgroundColor = textBackgroundColor;
    text.editable = textEditable;
    text.scrollEnabled = textScrollEnabled;
    text.autoresizingMask = textAutoresizingMask;
    
    return text;
}

+ (UITableView *)tableWithFrame:(CGRect)tableFrame
                       andStyle:(UITableViewStyle)tableStyle
              andSeparatorStyle:(UITableViewCellSeparatorStyle)tableSeparatorStyle
              andSeparatorColor:(UIColor *)tableSeparatorColor
               andScrollEnabled:(BOOL)tableScrollEnabled
             andBackgroundColor:(UIColor *)tableBackgroundColor
{
    UITableView *table = [[UITableView alloc] initWithFrame:tableFrame style:tableStyle];
    table.separatorStyle = tableSeparatorStyle;
    table.separatorColor = tableSeparatorColor;
    table.scrollEnabled = tableScrollEnabled;
    table.backgroundColor = tableBackgroundColor;
    
    return table;
}

+ (UIWebView *)webWithFrame:(CGRect)webFrame
         andBackgroundColor:(UIColor *)backgroundColor
andScrollViewBackgroundColor:(UIColor *)scrollViewBackgroundColor
            andScrollEnable:(BOOL)scrollEnable
         andScalesPageToFit:(BOOL)scalesPageToFit
                  andOpaque:(BOOL)opaque
{
    UIWebView *web = [[UIWebView alloc] initWithFrame:webFrame];
    web.backgroundColor = backgroundColor;
    web.scrollView.backgroundColor = scrollViewBackgroundColor;
    web.scrollView.scrollEnabled = scrollEnable;
    web.scalesPageToFit = scalesPageToFit;
    web.opaque = opaque;
    
    return web;
}

+ (void)alertTitle:(NSString *)title
        andMessage:(NSString *)message
    andButtonTitle:(NSString *)buttonTitle
andOtherButtonTitle:(NSString *)otherButtonTitle
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title
                                                    message:message
                                                   delegate:nil
                                          cancelButtonTitle:buttonTitle
                                          otherButtonTitles:otherButtonTitle, nil];
    [alert show];
}

@end
