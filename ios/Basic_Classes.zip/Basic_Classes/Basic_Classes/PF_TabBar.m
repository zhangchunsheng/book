//
//  PF_TabBar.m
//  Basic_Classes
//
//  Created by Adm on 14-2-12.
//  Copyright (c) 2014年 PFei_He. All rights reserved.
//

#import "PF_TabBar.h"

@interface PF_TabBar ()

@end

@implementation PF_TabBar

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

#pragma mark - View Management

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initViewController];
    [self initTabBar];
}

//初始化子控制器
-(void)initViewController
{
    NSArray *unloginView = [[NSArray alloc] initWithObjects:nil];
    self.selectArray = [[NSMutableArray alloc] initWithCapacity:5];
    self.unselectArray = [[NSMutableArray alloc] initWithCapacity:5];
    for (UIViewController *viewController in unloginView)
    {
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:viewController];
        [self.unselectArray addObject:nav];
    }
    self.viewControllers = self.unselectArray;
}

//创建自定义TabBar
- (void)initTabBar
{
    [self setTabBarHidden:YES andCustomTabBarHidden:NO];
    
    UIImage *tabBarImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"" ofType:@""]];
    
    if (!_customTabBar)
        _customTabBar = [[UIImageView alloc] initWithImage:tabBarImage];
    _customTabBar.frame = CGRectMake(0, self.view.frame.size.height - 49, 320, 49);
    _customTabBar.userInteractionEnabled = YES;
    [self.view addSubview:_customTabBar];
    
    if (!isSelect)
        //未选中的图片
        _background = @[@"", @"", @"", @"", @""];
    
    //选中的图片
    _heightBackground = @[@"", @"", @"", @"", @""];
    
    //TabBar的文字
    NSArray *tabBarArray = @[@"", @"", @"", @"", @""];
    _tabBarButton = [[NSMutableArray alloc] initWithCapacity:5];
    
    for(int i = 0; i < [_background count]; i++)
    {
        //TabBar的图片
        NSString *normal = [[NSString alloc] initWithFormat:@"%@", [_background objectAtIndex:i]];
        NSString *highlighted = [[NSString alloc] initWithFormat:@"%@", [_heightBackground objectAtIndex:i]];
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake((i * 64), 0, 64, 49);
        button.tag = i + 1;
        [button setImage:[UIImage imageNamed:normal] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:highlighted] forState:UIControlStateSelected];
        
        //TabBar的文字
        UILabel *tabBarLabel = [[UILabel alloc]initWithFrame:CGRectMake((i * 64), 38, 64, 7)];
        tabBarLabel.font = [UIFont systemFontOfSize:8];
        tabBarLabel.textAlignment = NSTextAlignmentCenter;
        tabBarLabel.text = tabBarArray[i];
        tabBarLabel.textColor = [UIColor grayColor];
        tabBarLabel.backgroundColor = [UIColor clearColor];
        [_customTabBar addSubview:tabBarLabel];
        
        //选中的Button
        if(i == 0) {
            button.selected = YES;
        }
        [button addTarget:self action:@selector(selectTabBar:) forControlEvents:UIControlEventTouchDown];
        [_tabBarButton addObject:button];
        [_customTabBar addSubview:button];
    }
    [self.view addSubview:_customTabBar];
}

#pragma mark - TabBar Methods

//获取TabBar选中的Button
- (void)selectTabBar:(UIButton *)button
{
    self.selectedIndex = button.tag - 1;
    for (int i = 0; i < 5; i++)
    {
        UIButton *button = [_tabBarButton objectAtIndex:i];
        button.selected = NO;
        button.frame =  CGRectMake((i * 64), 0, 64, 49);
        
    }
    button.selected = YES;
}

//隐藏TabBar
- (void)setTabBarHidden:(BOOL)tabBarHidden andCustomTabBarHidden:(BOOL)customTabBarHidden
{
    //隐藏系统TabBar
    UIView *tab = self.view;
    if ([tab.subviews count] < 2) {
        return;
    }
    UIView *view;
    if ([[tab.subviews objectAtIndex:0] isKindOfClass:[UITabBar class]]) {
        view = [tab.subviews objectAtIndex:1];
    }else{
        view = [tab.subviews objectAtIndex:0];
    }
    if (tabBarHidden) {
        view.frame = tab.bounds;
        self.tabBar.hidden = tabBarHidden;
    }else
        view.frame = CGRectMake(tab.bounds.origin.x, tab.bounds.origin.y, tab.bounds.size.width, tab.bounds.size.height);
    
    //隐藏自定义TabBar
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:1];
    if(customTabBarHidden)
        self.customTabBar.hidden = YES;
    else
        self.customTabBar.hidden = NO;
    [UIView commitAnimations];
}

//设置TabBar可否随屏幕旋转
- (BOOL)shouldAutorotate
{
    return NO;
}

#pragma mark - Memory Management

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
