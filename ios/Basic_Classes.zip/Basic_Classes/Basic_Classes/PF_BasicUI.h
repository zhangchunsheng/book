//
//  PF_BasicUI.h
//  Basic_Classes
//
//  Created by Adm on 14-2-12.
//  Copyright (c) 2014年 PFei_He. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PF_BasicUI : UIView

/**
 *	@brief	UIButton
 */
+ (UIButton *)buttonWithType:(UIButtonType)buttonType
                    andFrame:(CGRect)buttonFrame
                    andTitle:(NSString *)buttonTitle
                andTitleFont:(int)titleFont
               andTitleColor:(UIColor *)titleColor
                    andImage:(UIImage *)buttonImage
            andSelectedImage:(UIImage *)buttonSelectedImage
          andBackgroundImage:(UIImage *)buttonBackgroundImage
  andSelectedBackgroundImage:(UIImage *)buttonSelectedBackgroundImage
                   andTarget:(id)buttonTarget
                   andAction:(SEL)buttonAction
            andControlEvents:(UIControlEvents)buttonForControlEvents;

/**
 *	@brief	UILabel
 */
+ (UILabel *)labelWithFrame:(CGRect)labelFrame
                    andText:(NSString *)labelText
                    andFont:(NSInteger)labelFont
           andTextAlignment:(NSTextAlignment)labelTextAlignment
               andTextColor:(UIColor *)labelTextColor
         andBackgroundColor:(UIColor *)labelBackgroundColor;

/**
 *	@brief	UITextField
 */
+ (UITextField *)textWithFrame:(CGRect)textFrame
                andBorderStyle:(UITextBorderStyle)textBorderStyle
                       andText:(NSString *)textText
                andPlaceholder:(NSString *)textPlaceholder
                       andFont:(NSInteger)textFont
              andTextAlignment:(NSTextAlignment)textTextAlignment
                  andTextColor:(UIColor *)textTextColor
            andBackgroundColor:(UIColor *)textBackgroundColor
       andClearsOnBeginEditing:(BOOL)textClearsOnBeginEditing;

/**
 *	@brief	UITextView
 */
+ (UITextView *)textWithFrame:(CGRect)textFrame
                      andText:(NSString *)textText
                      andFont:(NSInteger)textFont
                 andTextColor:(UIColor *)textTextColor
           andBackgroundColor:(UIColor *)textBackgroundColor
                  andEditable:(BOOL)textEditable
             andScrollEnabled:(BOOL)textScrollEnabled
          andAutoresizingMask:(UIViewAutoresizing)textAutoresizingMask;

/**
 *	@brief  UITableView
 */
+ (UITableView *)tableWithFrame:(CGRect)tableFrame
                       andStyle:(UITableViewStyle)tableStyle
              andSeparatorStyle:(UITableViewCellSeparatorStyle)tableSeparatorStyle
              andSeparatorColor:(UIColor *)tableSeparatorColor
               andScrollEnabled:(BOOL)tableScrollEnabled
             andBackgroundColor:(UIColor *)tableBackgroundColor;

/**
 *	@brief  UIWebView
 */
+ (UIWebView *)webWithFrame:(CGRect)webFrame
         andBackgroundColor:(UIColor *)backgroundColor
andScrollViewBackgroundColor:(UIColor *)scrollViewBackgroundColor
            andScrollEnable:(BOOL)scrollEnable
         andScalesPageToFit:(BOOL)scalesPageToFit
                  andOpaque:(BOOL)opaque;

/**
 *  @brief	提示框（标题，内容，按钮内容）
 */
+ (void)alertTitle:(NSString *)title
        andMessage:(NSString *)message
    andButtonTitle:(NSString *)buttonTitle
andOtherButtonTitle:(NSString *)otherButtonTitle;

@end
