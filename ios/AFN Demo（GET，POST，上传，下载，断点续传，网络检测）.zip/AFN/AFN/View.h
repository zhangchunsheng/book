//
//  View.h
//  AFN
//
//  Created by Adm on 14-2-13.
//  Copyright (c) 2014年 PFei_He. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface View : UIViewController
{
    UIButton *buttonGet;                    //GET请求的按钮（iOS 6-7）
    
    UIButton *buttonPost;                   //POST请求的按钮（iOS 6-7）
    
    UIButton *buttonUpload;                 //上传的按钮（iOS 6-7）
    
    UIButton *buttonDownloadStart;          //开始下载的按钮（iOS 6-7）
    
    UIButton *buttonDownloadPause;          //暂停下载的按钮（iOS 6-7）
    
    UIButton *buttonDownloadResume;         //继续下载的按钮（iOS 6-7）
    
    UIButton *buttonUploadFor7;             //上传请求的按钮（iOS 7）
    
    UIButton *buttonDownloadFor7;           //下载请求的按钮（iOS 7）
    
    AFHTTPRequestOperationManager *manager; //创建请求（iOS 6-7）
    
    AFURLSessionManager *sessionManager;    //创建请求（iOS7专用）
    
    AFHTTPRequestOperation *operation;      //创建请求管理（用于上传和下载）
}

@end
