//
//  View.m
//  AFN-2.x
//
//  Created by Adm on 14-1-26.
//  Copyright (c) 2014年 Adm. All rights reserved.
//

#import "View.h"

@interface View ()

@end

@implementation View

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //GET请求的按钮
    UIButton *buttonGet = [UIButton buttonWithType:UIButtonTypeSystem];
    buttonGet.frame = CGRectMake(100, 100, 60, 20);
    [buttonGet setTitle:@"GET" forState:UIControlStateNormal];
    [buttonGet addTarget:self action:@selector(methodGet) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:buttonGet];
    
    //POST请求的按钮
    UIButton *buttonPost = [UIButton buttonWithType:UIButtonTypeSystem];
    buttonPost.frame = CGRectMake(160, 100, 60, 20);
    [buttonPost setTitle:@"POST" forState:UIControlStateNormal];
    [buttonPost addTarget:self action:@selector(methodPost) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:buttonPost];
    
    //Upload请求的按钮
    UIButton *buttonUpload = [UIButton buttonWithType:UIButtonTypeSystem];
    buttonUpload.frame = CGRectMake(100, 140, 60, 20);
    [buttonUpload setTitle:@"Upload" forState:UIControlStateNormal];
    [buttonUpload addTarget:self action:@selector(methodUpload) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:buttonUpload];
}

#pragma mark - GET

//GET请求
- (void)methodGet
{
    //致空请求
    if (manager) {
        manager = nil;
    }
    
    //创建请求
    manager = [AFHTTPRequestOperationManager manager];
    
    //设置请求的解析器为AFHTTPResponseSerializer（用于直接解析数据NSData），默认为AFJSONResponseSerializer（用于解析JSON）
//    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    //添加JSON的数据类型，本Demo已在AFNetworking的源代码添加此数据类型，在AFURLResponseSerialization.m文件的第149行-第159行添加
//    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    
    //发送GET请求
    [manager GET:@"接口地址" parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        //请求成功（当解析器为AFJSONResponseSerializer时）
        NSLog(@"success:%@", responseObject);
        
        //请求成功（当解析器为AFHTTPResponseSerializer时）
//        NSString *JSONString = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
//        NSLog(@"success:%@", JSONString);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        //请求失败
        NSLog(@"failure:%@", error);
        
    }];
}

#pragma mark - POST

//POST请求
- (void)methodPost
{
    //致空请求
    if (manager) {
        manager = nil;
    }
    
    //添加参数，Objective-C 2.0新语法
    NSDictionary *parameters = @{@"Key": @"Object",
                                 @"Key": @"Object"};
    //添加参数，旧语法
//    NSMutableDictionary *parameters = [[NSMutableDictionary alloc] init];
//    [parameters setObject:@"" forKey:@""];
    
    //创建请求
    manager = [AFHTTPRequestOperationManager manager];
    
    //设置请求的解析器为AFHTTPResponseSerializer（用于直接解析数据NSData），默认为AFJSONResponseSerializer（用于解析JSON）
//    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    //发送POST请求
    [manager POST:@"接口地址" parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        //请求成功（当解析器为AFJSONResponseSerializer时）
        NSLog(@"success:%@", responseObject);
        
        //请求成功（当解析器为AFHTTPResponseSerializer时）
//        NSString *JSONString = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
//        NSLog(@"success:%@", JSONString);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        //请求失败
        NSLog(@"failure:%@", error);
        
    }];
}

#pragma mark - Upload

//上传（以图片为例）
- (void)methodUpload
{
    //致空请求
    if (manager) {
        manager = nil;
    }
    
    //添加参数，Objective-C 2.0新语法
    NSDictionary *parameters = @{@"Key": @"Object",
                                 @"Key": @"Object"};
    //添加参数，旧语法
//    NSMutableDictionary *parameters = [[NSMutableDictionary alloc] init];
//    [parameters setObject:@"" forKey:@""];
    
    //创建请求
    manager = [AFHTTPRequestOperationManager manager];
    
    //设置请求的解析器为AFHTTPResponseSerializer（用于直接解析数据NSData），默认为AFJSONResponseSerializer（用于解析JSON）
//    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    //发送POST请求，添加需要发送的文件，此处为图片
    [manager POST:@"接口地址" parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
        //添加图片，并对其进行压缩（0.0为最大压缩率，1.0为最小压缩率）
        NSData *imageData = UIImageJPEGRepresentation([UIImage imageNamed:@"图片名字"], 1.0);
        
        //添加要上传的文件，此处为图片
        [formData appendPartWithFileData:imageData name:@"服务器放图片的参数名（Key）" fileName:@"图片名字" mimeType:@"文件类型（此处为图片格式，如image/jpeg）"];
        
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        //请求成功（当解析器为AFJSONResponseSerializer时）
        NSLog(@"success:%@", responseObject);
        
        //请求成功（当解析器为AFHTTPResponseSerializer时）
//        NSString *JSONString = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
//        NSLog(@"success:%@", JSONString);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        //请求失败
        NSLog(@"failure:%@", error);
        
    }];
}

#pragma mark - Memory Management

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
