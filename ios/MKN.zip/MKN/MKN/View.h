//
//  View.h
//  MKN
//
//  Created by Adm on 14-1-26.
//  Copyright (c) 2014年 Adm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface View : UIViewController
{
    MKNetworkEngine *engine;    //创建请求
}

@end
