//
//  View.m
//  MKN
//
//  Created by Adm on 14-1-26.
//  Copyright (c) 2014年 Adm. All rights reserved.
//

#import "View.h"

@interface View ()

@end

@implementation View

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    //GET请求的按钮
    UIButton *buttonGet = [UIButton buttonWithType:UIButtonTypeSystem];
    buttonGet.frame = CGRectMake(100, 100, 60, 20);
    [buttonGet setTitle:@"GET" forState:UIControlStateNormal];
    [buttonGet addTarget:self action:@selector(methodGet) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:buttonGet];
    
    //POST请求的按钮
    UIButton *buttonPost = [UIButton buttonWithType:UIButtonTypeSystem];
    buttonPost.frame = CGRectMake(160, 100, 60, 20);
    [buttonPost setTitle:@"POST" forState:UIControlStateNormal];
    [buttonPost addTarget:self action:@selector(methodPost) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:buttonPost];
    
    //Upload请求的按钮
    UIButton *buttonUpload = [UIButton buttonWithType:UIButtonTypeSystem];
    buttonUpload.frame = CGRectMake(100, 140, 60, 20);
    [buttonUpload setTitle:@"Upload" forState:UIControlStateNormal];
    [buttonUpload addTarget:self action:@selector(methodUpload) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:buttonUpload];
    
    //创建请求，设置接口路径
    engine = [[MKNetworkEngine alloc] initWithHostName:@"接口共用的路径"];
}

#pragma mark - GET

//GET请求
- (void)methodGet
{
    //设置请求，添加接口，参数，请求方法
    MKNetworkOperation *op = [engine operationWithPath:@"请求的接口" params:nil httpMethod:@"GET"];
    
    //发送请求
    [op addCompletionHandler:^(MKNetworkOperation *completedOperation) {
        
        //请求完成
        NSLog(@"completion:%@", [completedOperation responseJSON]);
        
    } errorHandler:^(MKNetworkOperation *completedOperation, NSError *error) {
        
        //请求失败
        NSLog(@"error:%@", [error localizedFailureReason]);
        
    }];
    
    //添加请求（队列请求）
    [engine enqueueOperation:op];
}

#pragma mark - POST

//POST请求
- (void)methodPost
{
    //添加参数，Objective-C 2.0新语法
    NSDictionary *params = @{@"Key": @"Object",
                                 @"Key": @"Object"};
    //添加参数，旧语法
//    NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
//    [parameters setObject:@"" forKey:@""];
    
    //设置请求，添加接口，参数，请求方法
    MKNetworkOperation *op = [engine operationWithPath:@"请求的接口" params:params httpMethod:@"POST"];
    
    //发送请求
    [op addCompletionHandler:^(MKNetworkOperation *completedOperation) {
        
        //请求完成
        NSLog(@"completion:%@", [completedOperation responseJSON]);
        
    } errorHandler:^(MKNetworkOperation *completedOperation, NSError *error) {
        
        //请求失败
        NSLog(@"error:%@", [error localizedFailureReason]);
        
    }];
    
    //添加请求（队列请求）
    [engine enqueueOperation:op];
}

#pragma mark - Upload

//上传
- (void)methodUpload
{
    //添加参数，Objective-C 2.0新语法
    NSDictionary *params = @{@"Key": @"Object",
                             @"Key": @"Object"};
    //添加参数，旧语法
//    NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
//    [parameters setObject:@"" forKey:@""];
    
    //设置请求，添加接口，参数，请求方法
    MKNetworkOperation *op = [engine operationWithURLString:@"请求的接口" params:params httpMethod:@"POST"];
    
    //添加要上传的文件
    NSString *file = [[NSBundle mainBundle] pathForResource:@"上传的文件名" ofType:@"文件类型"];
    [op addFile:file forKey:@"服务器放文件的参数名（Key）"];
    
    //发送请求
    [op addCompletionHandler:^(MKNetworkOperation *completedOperation) {
        
        //请求完成
        NSLog(@"completion:%@", [completedOperation responseJSON]);
        
    }errorHandler:^(MKNetworkOperation *completedOperation, NSError *error) {
        
        //请求失败
        NSLog(@"error:%@", [error localizedFailureReason]);
        
    }];
    
    //添加请求（队列请求）
    [engine enqueueOperation:op];
}

#pragma mark - Memory Management

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
